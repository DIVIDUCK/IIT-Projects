# Imports Database class from the project to provide basic functionality for database access
from database import Database
from boto3.dynamodb.conditions import Key, Attr

DEVICES = ['BSM_G101', 'BSM_G102']
DATA_TYPES = ['Temperature', 'SPO2', 'HeartRate']


# User document contains username (String), email (String), and role (String) fields
class RawDataModel:
    RAW_DATA_TABLE = 'bsm_data'

    def __init__(self):
        self._db = Database()
        self.__Raw_Sensor_Data = {}

    # Since username should be unique in users collection, this provides a way to fetch the user document based on the username
    def find_by_device_id_and_timestamp(self, device_id, timestamp):
        key = {'deviceid': device_id, 'timestamp': timestamp}
        return self.__find(key)

    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        user_item = self._db.get_single_data(RawDataModel.RAW_DATA_TABLE, key)
        return user_item

    def find_datatype_timestamp_range(self, start_timestamp, end_timestamp):
        temp_dict = {}
        for device_id in DEVICES:
            for datatype in DATA_TYPES:
                key = Key('deviceid').eq(device_id) & Key('datatype').eq(datatype) & Attr('timestamp').gte(
                    start_timestamp) & Attr('timestamp').lte(end_timestamp)
                bsm_items = self._db.get_multiple_data(RawDataModel.RAW_DATA_TABLE, key)
                temp_dict[datatype] = bsm_items
            self.__Raw_Sensor_Data[device_id] = temp_dict
            temp_dict = {}
        #print(self.__Raw_Sensor_Data)
        return self.__Raw_Sensor_Data

