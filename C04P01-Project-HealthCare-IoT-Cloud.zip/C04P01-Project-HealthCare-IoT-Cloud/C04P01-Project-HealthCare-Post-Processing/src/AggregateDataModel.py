# Imports Database class from the project to provide basic functionality for database access
from database import Database
from RawDataModel import RawDataModel
from datetime import datetime, timedelta
import functools
import time
from boto3.dynamodb.conditions import Key, Attr


# User document contains username (String), email (String), and role (String) fields
class AggregateModel:
    AGGREGATE_TABLE = 'bsm_agg_data'

    def __init__(self):
        self._db = Database()
        self.__Raw_Data = RawDataModel()

    def find_by_data_type(self, datatype, start, end):
        key = Key('deviceid').begins_with(datatype) & Attr('timestamp').gte(
            start) & Attr('timestamp').lte(end)
        bsm_agg_items = self._db.get_multiple_data(AggregateModel.AGGREGATE_TABLE, key)
        return bsm_agg_items

    # Since username should be unique in users collection, this provides a way to fetch the user document based on the username
    def aggregate(self, start_timestamp, end_timestamp):
        self.__latest_error = ''
        value_list = []
        end_time = datetime.fromisoformat(end_timestamp)
        end_time_temp = end_time + timedelta(minutes=2)
        end_timestamp_temp = end_time_temp.isoformat()
        end_timestamp_string = end_timestamp_temp.replace("T", " ")
        temp_dict = self.__Raw_Data.find_datatype_timestamp_range(start_timestamp, end_timestamp_string)
        for key, value in temp_dict.items():
            for key1, value1 in value.items():
                for temp_data, current in enumerate(value1[:-1]):
                    current_date_time_stamp = datetime.fromisoformat(current['timestamp'])
                    next_date_time_stamp = datetime.fromisoformat(value1[temp_data + 1]['timestamp'])
                    if current_date_time_stamp.minute == next_date_time_stamp.minute:
                        value_list.append(current['value'])
                    else:
                        value_list.append(current['value'])
                        maximum = functools.reduce(lambda a, b: a if a > b else b, value_list)
                        minimum = functools.reduce(lambda a, b: a if a < b else b, value_list)
                        sum1 = functools.reduce(lambda a, b: (a + b), value_list)
                        average = sum1 / len(value_list)
                        future_timestamp = current_date_time_stamp.replace(second=0, microsecond=0)
                        future_timestamp_string = future_timestamp.isoformat()
                        future_timestamp_string_new = future_timestamp_string.replace("T", " ")
                        item = {
                            'deviceid': f'{key1}:{key}',
                            'max': maximum,
                            'min': minimum,
                            'average': average,
                            'timestamp': future_timestamp_string_new,
                        }
                        print(item)
                        self._db.insert_single_data(AggregateModel.AGGREGATE_TABLE, item)
                time.sleep(2)
