# Imports Database class from the project to provide basic functionality for database access
from decimal import Decimal

from database import Database
from AggregateDataModel import AggregateModel
import json

RULE_CONFIG_PATH = '../config/Rule.json'


# User document contains username (String), email (String), and role (String) fields
class AlertModel:
    ALERT_TABLE = 'bsm_alerts'

    def __init__(self):
        self._db = Database()
        self.__agg_db = AggregateModel()

    # Since username should be unique in users collection, this provides a way to fetch the user document based on the username
    def generate_alerts_based_rules(self, start, end):
        f = open(RULE_CONFIG_PATH)
        rule_list = json.load(f)
        for rules in rule_list:
            trigger_count = 0
            data_items = self.__agg_db.find_by_data_type(rules['type'], start, end)
            for items in data_items:
                if int(items['average']) > rules['avg_max'] or int(items['average']) < rules['avg_min']:
                    trigger_count = trigger_count + 1
                    if trigger_count == 1:
                        timestamp = items['timestamp']
                    if trigger_count >= rules['trigger_count']:
                        item = {
                            'deviceid': items['deviceid'],
                            'timestamp': timestamp,
                            'description': rules['description']
                        }
                        print(rules['description'])
                        self._db.insert_single_data(AlertModel.ALERT_TABLE, item)
                        trigger_count = 0
                else:
                    trigger_count = 0





