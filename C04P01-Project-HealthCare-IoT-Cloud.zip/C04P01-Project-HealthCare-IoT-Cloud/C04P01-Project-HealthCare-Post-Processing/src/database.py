# Imports boto3 for dynamoDB for base level access to the AWS DynamoDB

import boto3


class Database:

    def __init__(self):
        self._dynamodb = boto3.resource('dynamodb')

    # This method finds a single document using field information provided in the key parameter
    # It assumes that the key returns a unique document. It returns None if no document is found
    def get_single_data(self, table, search_string):
        dynamodb_table = self._dynamodb.Table(table)
        response = dynamodb_table.get_item(Key=search_string)
        item = response['Item']
        return item

    # This method finds multple documents based on the key provided
    def get_multiple_data(self, table, key):
        dynamodb_table = self._dynamodb.Table(table)
        response = dynamodb_table.scan(FilterExpression=key)
        items = response['Items']
        return items

    # This method inserts the data in a new document. It assumes that any uniqueness check is done by the caller
    def insert_single_data(self, table, data):
        dynamodb_table = self._dynamodb.Table(table)
        dynamodb_table.put_item(Item=data)
