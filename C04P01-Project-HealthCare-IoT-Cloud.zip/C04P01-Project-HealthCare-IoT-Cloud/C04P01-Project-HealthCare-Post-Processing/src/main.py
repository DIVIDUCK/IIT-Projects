from AggregateDataModel import AggregateModel
from AlertDataModel import AlertModel
import time

AggDataModel_service = AggregateModel()
AggDataModel_service.aggregate("2021-10-31 21:00:00", "2021-10-31 22:00:00")

time.sleep(2)

AlertModel_service = AlertModel()
AlertModel_service.generate_alerts_based_rules("2021-10-31 21:00:00", "2021-10-31 22:00:00")