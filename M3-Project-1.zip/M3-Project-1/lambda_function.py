from pprint import pprint
from decimal import Decimal
import boto3
import json
import csv
import datetime
import os
import random
import base64
from dateutil import parser


def lambda_handler(event, context):
    dynamodb_res = boto3.resource('dynamodb', region_name='us-east-1')
    for record in event['Records']:
        payload = base64.b64decode(record['kinesis']['data'])
        payload = str(payload, 'utf-8')
        payload_rec = json.loads(payload, parse_float=Decimal)
        datetime_str = payload_rec['TimeStamp']
        datetime_object = parser.parse(datetime_str)
        payload_rec['Date'] = str(datetime.datetime.date(datetime_object))
        pprint(payload_rec)
        table = dynamodb_res.Table('Stock_Stream')
        if( payload_rec['Closing_Price'] >= (payload_rec['52WeekLowVal'] * Decimal(1.2)) or 
            payload_rec['Closing_Price'] <= (payload_rec['52WeekHighVal'] * Decimal(0.8)) ):
            response = table.get_item(Key={'Stock_Id':payload_rec['Stock_Id'] , 'Date': str(payload_rec['Date'])})
            if 'Item' in response:
                response = 0
            else:
                response = table.put_item(Item=payload_rec)
                client = boto3.client('sns', region_name='us-east-1')
                topic_arn = "arn:aws:sns:us-east-1:982673473168:StockNotification"
                try:
                    client.publish(TopicArn=topic_arn, Message="Closing Price has crossed 120% of 52 week low and 80% of 52 week high ", Subject="PriceHitting+/-")
                    response = 1
                except Exception:
                    response = 0
        else:
            response = 0
    return response
