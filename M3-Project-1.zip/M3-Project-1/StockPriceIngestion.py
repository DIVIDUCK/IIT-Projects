import json
import boto3
import yfinance as yf
import datetime
import pandas as pd

stock_list = ["MSFT", "MVIS", "GOOG", "SPOT", "INO", "OCGN", "ABML", "RLLCF", "JNJ", "PSFE"]

# Your goal is to get per-hour stock price data for a time range for the ten stocks specified in the doc.
# Further, you should call the static info api for the stocks to get their current 52WeekHigh and 52WeekLow values.
# You should craft individual data records with information about the stockid, price, price timestamp, 52WeekHigh and 52WeekLow values and push them individually on the Kinesis stream

kinesis = boto3.client('kinesis', region_name = "us-east-1")
today = datetime.date.today()
yesterday = datetime.date.today() - datetime.timedelta(1)

for stock in stock_list:
    # Example of pulling the data between 2 dates from yfinance API
    stock_data = yf.Ticker(stock)
    ## Add additional code to call 'info' API to get 52WeekHigh and 52WeekLow refering this this link - https://pypi.org/project/yfinance/
    WeekHighVal = stock_data.info['fiftyTwoWeekHigh']
    WeekLowVal = stock_data.info['fiftyTwoWeekLow']
    data = yf.download(stock, group_by="Ticker", start= yesterday, end= today, interval = '1h' )
    data['StockName'] = stock
    data['52WeekHighVal'] = WeekHighVal
    data['52WeekLowVal'] = WeekLowVal
    new_data = data[['StockName', 'Close', '52WeekHighVal', '52WeekLowVal']].copy()
    data_dict = new_data.to_dict()
    json_dataset = {}
    for keys in data_dict['StockName']:
        json_dataset = {'TimeStamp': str(keys), 'Stock_Id':data_dict['StockName'][keys], 'Closing_Price':data_dict['Close'][keys], '52WeekHighVal':data_dict['52WeekHighVal'][keys], '52WeekLowVal': data_dict['52WeekLowVal'][keys] }
        json_dump = json.dumps(json_dataset)
        print(json_dump)
        response = kinesis.put_record(
            StreamName='Stock_Kinesis',
            Data=json_dump,
            PartitionKey='Stock_Id',
        )
        print(response)
