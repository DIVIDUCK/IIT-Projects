import json
import time
import re
import paho.mqtt.client as mqtt

HOST = "localhost"
PORT = 1883
WAIT_TIME = 0.25
LIGHT_DEVICE_COUNT = 3
AC_DEVICE_COUNT = 2


class Edge_Server:

    def __init__(self, instance_name):

        self._instance_id = instance_name
        self.client = mqtt.Client(self._instance_id)
        self.client.on_connect = self._on_connect
        self.client.on_message = self._on_message
        self.client.connect(HOST, PORT, keepalive=60)
        self.client.loop_start()
        self._registered_list = []

    # Terminating the MQTT broker and stopping the execution
    def terminate(self):
        self.client.disconnect()
        self.client.loop_stop()

    # Connect method to subscribe to various topics.     
    def _on_connect(self, client, userdata, flags, result_code):
        for count in range(LIGHT_DEVICE_COUNT):
            client.subscribe("registerdevices" + "Light" + str(count))
        for count in range(AC_DEVICE_COUNT):
            client.subscribe("registerdevices" + "AC" + str(count))

    # method to process the recieved messages and publish them on relevant topics 
    # this method can also be used to take the action based on received commands
    def _on_message(self, client, userdata, msg):
        encoding = 'utf-8'
        value = str(msg.payload, encoding)
        if msg.topic.count("registerdevices"):
            self._registered_list.append(value)
            client.subscribe(value + "/GetStatus")
            client.subscribe(value + "/SetStatus")
            client.subscribe(value + "/SetLightIntensity")
            client.subscribe(value + "/SetACTemperature")
            client.publish("registerconfirmation/" + value, f'Registration-Successful for {value}')
        elif msg.topic.count("GetStatus"):
            print(f'Status for the device {msg.topic} is {value}')
        elif msg.topic.count("SetStatus"):
            print(f'Status for the device {msg.topic} has been changed to {value}')
        elif msg.topic.count("SetLightIntensity"):
            print(f'Light intensity for {msg.topic} has been changed to {value}')
        elif msg.topic.count("SetACTemperature"):
            print(f'AC temperature for {msg.topic} has been changed to {value}')

    # Filtering the publish topics based on the different type of request recieved.
    def _filter_topics(self, topic):
        new_list = []
        if topic == "All":
            return self._registered_list
        else:
            for elements in self._registered_list:
                found = elements.find(topic)
                if found != -1:
                    new_list.append(elements)
            return new_list

    # Returning the current registered list
    def get_registered_device_list(self):
        return self._registered_list

    # Getting the status for the connected devices
    def get_status(self, topic):
        publish_list = self._filter_topics(topic)
        for elements in publish_list:
            self.client.publish(elements + "/Client" + "/GetStatus", "Get the status of the device")

    # Controlling and performing the operations on the devices
    # based on the request received
    def set_status(self, topic):
        publish_list = self._filter_topics(topic)
        for elements in publish_list:
            self.client.publish(elements + "/Client" + "/SetStatus", "Set the status of the device")

    def set_light_intensity(self, topic, intensity):
        publish_list = self._filter_topics(topic)
        for elements in publish_list:
            found = elements.find("AC")
            if found == -1:
                self.client.publish(elements + "/Client" + "/SetLightIntensity", intensity)

    def set_AC_temperature(self, topic, temperature):
        publish_list = self._filter_topics(topic)
        for elements in publish_list:
            found = elements.find("LIGHT")
            if found == -1:
                self.client.publish(elements + "/Client" + "/SetACTemperature", str(temperature))
