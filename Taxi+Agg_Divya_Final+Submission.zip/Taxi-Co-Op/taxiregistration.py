# Imports Database class from the project to provide basic functionality for database access
import datetime

from database import Database
# Imports ObjectId to convert to the correct format before querying in the db
from bson.objectid import ObjectId
import bcrypt
import random

Splash_water_park = {28.804040, 77.139685}
Pacific_mall_tagore_garden = {28.646279, 77.092306}
IGTR = {28.560901, 77.100374}
Ambience_mall = {28.508193, 77.092650}
Qutub_Minar = {28.5243966, 77.1855396}
DLF_mall = {28.584796, 77.332289}


# User document contains username (String), email (String), and role (String) fields
class TaxiModel:
    TAXI_COLLECTION = 'taxis'

    def __init__(self):
        self._db = Database()
        #self._db.delete_all_data(TaxiModel.TAXI_COLLECTION)
        self._latest_error = ''

    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new function call
    @property
    def latest_error(self):
        return self._latest_error

    def query_by_plate(self, plate, password):
        key = {'plate': plate}
        document = self.__find(key)
        if document:
            password_check = document['password']
            if password_check:
                if bcrypt.checkpw(password.encode('utf-8'), password_check):
                    return self.__find(key)
                else:
                    self._latest_error = f'Password for {plate} does not match'
                    return -1
            else:
                self._latest_error = f'The taxi does not have a password'
        else:
            self._latest_error = f'The taxi with {plate} does not exist'
            return -1

    def find_by_plate(self, plate):
        key = {'plate': plate}
        return self.__find(key)

    def update_by_plate(self, plate):
        myquery = {'plate': plate}
        newvalues = {"$set": {'BookingStatus': "Booked"}}
        return self.__update(myquery, newvalues)

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)

    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        taxi_document = self._db.get_single_data(TaxiModel.TAXI_COLLECTION, key)
        return taxi_document

    def __update(self, myquery, newvalues):
        taxi_obj_id = self._db.update_single_data(TaxiModel.TAXI_COLLECTION, myquery, newvalues)
        return self.find_by_object_id(taxi_obj_id)

    # This first checks if a user already exists with that username. If it does, it populates latest_error and returns -1
    # If a user doesn't already exist, it'll insert a new document and return the same to the caller
    def insert(self, plate, driver_name, password, email, phone_no, taxi_type, timestamp):
        self._latest_error = ''
        taxi_document = self.find_by_plate(plate)
        if taxi_document:
            self._latest_error = f'Taxi {plate} already exists'
            return -1
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        rand_lat = random.uniform(28.508193, 28.804040)
        rand_lon = random.uniform(77.092306, 77.332289)
        location = {'type': "Point", 'coordinates': [rand_lon, rand_lat]}
        taxi_data = {'plate': plate, 'drivername': driver_name, 'password': hashed, 'email': email, 'phoneno': phone_no, 'taxitype': taxi_type,
                     'timestamp': timestamp, 'location': location, 'BookingStatus': "Not Booked"}
        taxi_obj_id = self._db.insert_single_data(TaxiModel.TAXI_COLLECTION, taxi_data)
        return self.find_by_object_id(taxi_obj_id)

#if __name__ == "__main__":
#    model = TaxiModel()
#    for i in range(1,100):
 #       plate = f'TNDLA356{i}'
  #      Driver = f'Driver{i}'
  #      password = 'hermione'
  #      email = "hpcrary@gmail.com"
  #      phoneno = 9840490512
  #      if i%3 == 0:
   #         taxitype = "sedan"
   #     elif i%3 == 1:
    #        taxitype = "suv"
     #   else:
      #      taxitype = "hatchback"
      #  model.insert(plate, Driver, password, email, phoneno, taxitype, datetime.datetime.now())