# Imports Database class from the project to provide basic functionality for database access
from database import Database
# Imports ObjectId to convert to the correct format before querying in the db
from bson.objectid import ObjectId
import bcrypt
import random

Splash_water_park = {28.804040, 77.139685}
Pacific_mall_tagore_garden = {28.646279, 77.092306}
IGTR = {28.560901, 77.100374}
Ambience_mall = {28.508193, 77.092650}
Qutub_Minar = {28.5243966, 77.1855396}
DLF_mall = {28.584796, 77.332289}


# User document contains username (String), email (String), and role (String) fields
class UserModel:
    USER_COLLECTION = 'users'

    def __init__(self):
        self._db = Database()
        #self._db.delete_all_data(UserModel.USER_COLLECTION)
        self._latest_error = ''

    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new function call
    @property
    def latest_error(self):
        return self._latest_error

    def query_by_email(self, email, password):
        self._latest_error = ''
        key = {'email': email}
        document = self.__find(key)
        if document:
            password_check = document['password']
            print(type(password))
            print(type(password_check))
            if bcrypt.checkpw(password.encode('utf-8'), password_check):
                return self.__find(key)
            else:
                self._latest_error = f'Password for {email} does not match'
                return -1
        else:
            self._latest_error = f'The user with {email} does not exist'
            return -1

    def find_by_email(self, email):
        key = {'email': email}
        return self.__find(key)

    def update_by_email(self, email):
        myquery = {'email': email}
        newvalues = {"$set": {'BookingStatus': "Booked"}}
        return self.__update(myquery, newvalues)

    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        user_document = self._db.get_single_data(UserModel.USER_COLLECTION, key)
        return user_document

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)

    def __update(self, myquery, newvalues):
        taxi_obj_id = self._db.update_single_data(UserModel.USER_COLLECTION, myquery, newvalues)
        return self.find_by_object_id(taxi_obj_id)

    # This first checks if a user already exists with that username. If it does, it populates latest_error and returns -1
    # If a user doesn't already exist, it'll insert a new document and return the same to the caller
    def insert(self, username, password, email, phoneno, timestamp):
        self._latest_error = ''
        user_document = self.find_by_email(email)
        if user_document:
            self._latest_error = f'The user {username} already exists'
            return -1
        hashed = bcrypt.hashpw(password.encode('utf-8', 'strict'), bcrypt.gensalt())
        print(type(hashed))
        rand_lat = random.uniform(28.508193, 28.804040)
        rand_lon = random.uniform(77.092306, 77.332289)
        location = {'type': "Point", 'coordinates': [rand_lon, rand_lat]}
        user_data = {'username': username, 'password': hashed, 'email': email, 'phoneno': phoneno,
                     'timestamp':timestamp,'location': location, 'BookingStatus' : "Not Booked"}
        user_obj_id = self._db.insert_single_data(UserModel.USER_COLLECTION, user_data)
        return self.find_by_object_id(user_obj_id)
