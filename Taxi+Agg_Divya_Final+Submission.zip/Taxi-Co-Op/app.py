from flask import Flask, render_template, request, url_for, redirect, session

from taxiregistration import TaxiModel
from userregistration import UserModel
from tripdetails import TripDetails
from flask import json
import datetime

# set app as a Flask instance
app = Flask(__name__)
# encryption relies on secret keys so they could be run
app.secret_key = "testing"


@app.route("/", methods=['post', 'get'])
def base():
    return render_template('base.html')


# assign URLs to have a particular route
@app.route("/user_register", methods=['post', 'get'])
def index():
    message = ''
    # if method post in index
    if "email" in session:
        return redirect(url_for("logged_in"))
    if request.method == "POST":
        user = request.form.get("fullname")
        email = request.form.get("email")
        phone_no = request.form.get("phoneno")
        password1 = request.form.get("password")
        password2 = request.form.get("password2")
        if password1 != password2:
            message = 'Passwords should match!'
            return render_template('index.html', message=message)
        user1 = UserModel()
        return_val = user1.insert(user, password1, email, phone_no, datetime.datetime.utcnow())
        if return_val == -1:
            return render_template('index.html', message=user1.latest_error)
        else:
            new_email = return_val['email']
            # if registered redirect to logged in as the registered user
            return redirect(url_for("logged_in"))
    return render_template('index.html')


@app.route("/user_login", methods=["POST", "GET"])
def user_login():
    message = 'Please login to your account'
    if "email" in session:
        return redirect(url_for("logged_in"))
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        model = UserModel()
        return_val = model.query_by_email(email, password)
        if return_val == -1:
            return render_template('login.html', message=model.latest_error)
        else:
            session["email"] = return_val['email']
            return render_template('logged_in.html', message=email)
    return render_template('index.html')


@app.route("/taxi_booking/<taxitype>", methods=["POST", "GET"])
def taxi_booking(taxitype):
    if "email" in session:
        email = session["email"]
        taxitype = taxitype
        model = TripDetails()
        return_val = model.insert(email, taxitype, datetime.datetime.utcnow())
        if return_val == -1:
            return render_template('login.html', message=model.latest_error)
        else:
            response = app.response_class(
                response=return_val,
                status=200,
                mimetype='application/json'
            )
            return response
    else:
        return render_template('login.html', message="User not logged in")

@app.route("/notify_taxis", methods=["POST", "GET"])
def notify_booking():
    if "email" in session:
        model = TripDetails()
        model.notify_taxis(session["email"])
    else:
        return render_template('login.html', message="User not logged in")

@app.route("/notify_users/<email>", methods=["POST", "GET"])
def notify_user_booking(email):
    if "taxiplate" in session:
        model = TripDetails()
        model.accept_and_notify_users(email, session["taxiplate"])
    else:
        return render_template('login.html', message="User not logged in")

@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email = session["email"]
        return render_template('logged_in.html', email=email)
    else:
        return redirect(url_for("user_login"))


@app.route("/user_logout", methods=["POST", "GET"])
def user_logout():
    if "email" in session:
        session.pop("email", None)
        return render_template("signout.html")
    else:
        return render_template('index.html')


# assign URLs to have a particular route
@app.route("/taxi_register", methods=['post', 'get'])
def index1():
    message = ''
    # if method post in index
    if "taxiplate" in session:
        return redirect(url_for("taxi_logged_in"))
    if request.method == "POST":
        drivername = request.form.get("fullname")
        email = request.form.get("taximail")
        phone_no = request.form.get("phoneno")
        plate_no = request.form.get("taxiplate")
        taxi_type = request.form.get("taxitype")
        password1 = request.form.get("password")
        password2 = request.form.get("password2")
        if password1 != password2:
            message = 'Passwords should match!'
            return render_template('index1.html', message=message)
        taxi1 = TaxiModel()
        return_val = taxi1.insert(plate_no, drivername, password1, email, phone_no, taxi_type,
                                  datetime.datetime.utcnow())
        if return_val == -1:
            return render_template('index1.html', message=taxi1.latest_error)
        else:
            new_plate = return_val['plate']
            # if registered redirect to logged in as the registered user
            return render_template('taxi_logged_in.html', taxiplate=new_plate)
    return render_template('index1.html')


@app.route("/taxi_login", methods=["POST", "GET"])
def taxi_login():
    render_template('taxi_login.html', message='Please login to your account')
    if "taxiplate" in session:
        return redirect(url_for("taxi_logged_in"))
    if request.method == "POST":
        plate = request.form.get("taxiplate")
        password = request.form.get("password")
        model = TaxiModel()
        return_val = model.query_by_plate(plate, password)
        if return_val == -1:
            return render_template('taxi_login.html', message=model.latest_error)
        else:
            session["taxiplate"] = return_val['plate']
            return render_template('taxi_login.html', message=model.latest_error)
    return render_template('index1.html')


@app.route('/logged_in')
def taxi_logged_in():
    if "taxiplate" in session:
        new_plate = session["taxiplate"]
        return render_template('taxi_logged_in.html', taxiplate=new_plate)
    else:
        return redirect(url_for("taxi_login"))


@app.route("/taxi_logout", methods=["POST", "GET"])
def taxi_logout():
    if "taxiplate" in session:
        session.pop("taxiplate", None)
        return render_template("taxi_signout.html")
    else:
        return render_template('index1.html')


if __name__ == "__main__":
    app.run(debug=True)
