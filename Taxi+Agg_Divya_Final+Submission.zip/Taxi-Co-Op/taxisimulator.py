import datetime
import pprint
import time
import sched
from database import Database

TAXI_COLLECTION = 'taxis'
TAXI_SIMULATOR_COLLECTION = 'taxi_simulator'
message_list = []
_db = Database()


def publishLocationData(loop_count):
    PublishFreqLocation = 60
    if loop_count % PublishFreqLocation == 0:
        for document1 in _db.get_all_data(TAXI_COLLECTION):
            longitude = document1['location']['coordinates'][0]
            latitude = document1['location']['coordinates'][1]
            latitude = latitude + 0.001
            longitude = longitude + 0.001
            if 28.508193 >= latitude >= 28.804040:
                latitude = 28.508193
            elif 77.092306 >= longitude >= 77.332289:
                longitude = 77.092306
            location = {'type': "Point", 'coordinates': [longitude, latitude]}
            taxi_data = {'plate': document1['plate'], 'drivername': document1['drivername'], 'taxitype': document1['taxitype'],
                         'timestamp': datetime.datetime.now(), 'location': location}
            _db.insert_single_data(TAXI_SIMULATOR_COLLECTION, taxi_data)


def schedule_events():
    loopCount = 0
    scheduler = sched.scheduler(time.time, time.sleep)
    now = time.time()
    while True:
        try:
            scheduler.enterabs(now + loopCount, 1, publishLocationData, (loopCount,))
            loopCount += 1
            scheduler.run()
        except KeyboardInterrupt:
            break


if __name__ == "__main__":
    #_db.delete_all_data(TAXI_SIMULATOR_COLLECTION)
    schedule_events()
