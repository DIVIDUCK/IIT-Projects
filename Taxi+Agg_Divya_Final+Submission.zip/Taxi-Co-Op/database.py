# Imports MongoClient for base level access to the local MongoDB
import pymongo


class Database:
    # Class static variables used for database host ip and port information, database name
    # Static variables are referred to by using <class_name>.<variable_name>
    DB_NAME = 'location_db'

    def __init__(self):
        self._db_conn = pymongo.MongoClient("mongodb+srv://CloudCapstoneADP:hermione@clusteradp.4qgyzb3.mongodb.net/?retryWrites=true&w=majority")
        self._db = self._db_conn[Database.DB_NAME]
    
    # This method finds a single document using field information provided in the key parameter
    # It assumes that the key returns a unique document. It returns None if no document is found
    def get_single_data(self, collection, key):
        db_collection = self._db[collection]
        document = db_collection.find_one(key)
        return document

    def create_location_index(self, collection):
        db_collection = self._db[collection]
        db_collection.create_index([('location', pymongo.GEOSPHERE)])
    
    # This method finds multple documents based on the key provided
    def get_multiple_data(self, collection, key):
        db_collection = self._db[collection]
        documents = db_collection.find(key)
        return documents

    def get_multiple_data_location(self, collection, key, taxi_limit):
        db_collection = self._db[collection]
        documents = db_collection.find(key).limit(taxi_limit)
        return documents
    # This method finds multple documents based on the key provided
    def get_all_data(self, collection):
        db_collection = self._db[collection]
        documents = db_collection.find()
        return documents
    
    # This method inserts the data in a new document. It assumes that any uniqueness check is done by the caller
    def insert_single_data(self, collection, data):
        db_collection = self._db[collection]
        document = db_collection.insert_one(data)
        return document.inserted_id
    
    # This method inserts muliple documents. data should be a list of multiple dicts with keys already set as attributes
    def insert_multiple_data(self, collection, data):
        db_collection = self._db[collection]
        result = db_collection.insert_many(data)
        return result.inserted_ids

    # This method inserts muliple documents. data should be a list of multiple dicts with keys already set as attributes
    def update_single_data(self, collection, filter, data):
        db_collection = self._db[collection]
        result = db_collection.update_one(filter, data, upsert=False)
        return result.upserted_id

    # This method inserts muliple documents. data should be a list of multiple dicts with keys already set as attributes
    def update_multiple_data(self, collection, filter, data):
        db_collection = self._db[collection]
        result = db_collection.update_many(filter, data, upsert=False)
        return result.upserted_id

    def delete_all_data(self, collection):
        db_collection = self._db[collection]
        result = db_collection.delete_many({})
        return result.deleted_count
    
    # This method runs the aggregate pipeline functionality on mongo db and returns the result set
    def aggregate(self, collection, pipeline):
        db_collection = self._db[collection]
        documents = db_collection.aggregate(pipeline)
        return documents
    