import taxisimulator
import datetime

# admin access path for problem 1
#user_model = UserModel()
#user_model.query_by_email("New_User2@gmail.com", "hermione")
