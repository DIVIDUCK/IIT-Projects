# Imports Database class from the project to provide basic functionality for database access
from datetime import datetime, timedelta
import pprint

from bson import SON
from sns_basics import SnsWrapper
from database import Database
from taxiregistration import TaxiModel
from userregistration import UserModel

# Imports ObjectId to convert to the correct format before querying in the db
from bson.objectid import ObjectId
import bcrypt
import json
import logging
import time
import boto3
from botocore.exceptions import ClientError
TAXI_SIMULATOR_COLLECTION = 'taxi_simulator'
logger = logging.getLogger(__name__)

Splash_water_park = {28.804040, 77.139685}
Pacific_mall_tagore_garden = {28.646279, 77.092306}
IGTR = {28.560901, 77.100374}
Ambience_mall = {28.508193, 77.092650}
Qutub_Minar = {28.5243966, 77.1855396}
DLF_mall = {28.584796, 77.332289}

TRIP_STATE = ["Initialized", "Driver_Notified", "User_Notified", "Taxi_Booked"]


# User document contains username (String), email (String), and role (String) fields


class TripDetails:
    TRIP_COLLECTION = 'trip_details'

    def __init__(self):
        self._db = Database()
        self._user_model = UserModel()
        self._taxi_model = TaxiModel()
        self._db.create_location_index(TAXI_SIMULATOR_COLLECTION)
        self._latest_error = ''

    # Latest error is used to store the error string in case an issue. It's reset at the beginning of a new function call
    @property
    def latest_error(self):
        return self._latest_error

    def find_by_range(self, range_query):
        return self.__find(range_query)

    def find_by_email(self, email):
        key = {'user_email': email}
        return self.__find(key)

    # Private function (starting with __) to be used as the base for all find functions
    def __find(self, key):
        trip_document = self._db.get_single_data(TripDetails.TRIP_COLLECTION, key)
        return trip_document

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self.__find(key)

    def update_by_email(self, email, trip_state):
        myquery = {'email': email}
        newvalues = {"$set": {'TripState': trip_state}}
        return self.__update(myquery, newvalues)

    def __update(self, myquery, newvalues):
        taxi_obj_id = self._db.update_single_data(TripDetails.TRIP_COLLECTION, myquery, newvalues)
        return self.find_by_object_id(taxi_obj_id)

    # This first checks if a user already exists with that username. If it does, it populates latest_error and returns -1
    # If a user doesn't already exist, it'll insert a new document and return the same to the caller
    def insert(self, email, car_type, timestamp):
        self._latest_error = ''
        taxi_list = []
        current_location = {}
        trip_document = self.find_by_email(email)
        if trip_document:
            self._latest_error = f'The user {email} already exists'
            return -1
        user_document = self._user_model.find_by_email(email)
        if user_document:
            current_location = user_document['location']
        nearest_minute = timestamp - timedelta(minutes=1)
        nearest_query = {'location': {"$near": current_location}, 'timestamp': { "$gte" : nearest_minute }}
        for doc in self._db.get_multiple_data_location(TAXI_SIMULATOR_COLLECTION, nearest_query, 5):
            pprint.pprint(doc)
            if doc['taxitype'] == car_type:
                taxi_list.append(doc)
        trip_data = {'user_email': email, 'timestamp': timestamp, 'current_location': current_location,
                    'car_type': car_type, 'taxi_list': taxi_list, 'trip_state': TRIP_STATE[0]}
        self._db.insert_single_data(TripDetails.TRIP_COLLECTION, trip_data)
        return taxi_list

    @staticmethod
    def notify_taxis(email):
        sns_wrapper = SnsWrapper(boto3.resource('sns', region_name='us-east-1'))
        topic_name = f'taxi-driver-notify-{time.time_ns()}'
        topic = sns_wrapper.create_topic(topic_name)
        trip = TripDetails()
        document = trip.find_by_email(email)
        pprint.pprint(document)
        for taxis in document['taxi_list']:
            taxi = TaxiModel()
            document1 = taxi.find_by_plate(taxis['plate'])
            if document1['email'] != '':
                print(f"Subscribing {email} to {topic_name}.")
                email_sub = sns_wrapper.subscribe(topic, 'email', document1['email'])
                answer = input(
                    f"Confirmation email sent to {email}. To receive SNS messages, "
                    f"follow the instructions in the email. When confirmed, press "
                    f"Enter to continue.")
                while (email_sub.attributes['PendingConfirmation'] == 'true' and answer.lower() != 's'):
                    answer = input(
                        f"Email address {email} is not confirmed. Follow the "
                        f"instructions in the email to confirm and receive SNS messages. "
                        f"Press Enter when confirmed or enter 's' to skip. ")
                    email_sub.reload()
                print(f"Publishing a message to {topic_name}")
                msg_type = 'email'
                email = document1['email']
                message = f'Notification!User with {email} is waiting for this taxi'
                sns_wrapper.publish_message(
                        topic, message, {'email' : 'string'})
                trip.update_by_email(email, TRIP_STATE[1])

    @staticmethod
    def accept_and_notify_users(self, user_email, taxi_plate):
        sns_wrapper = SnsWrapper(boto3.resource('sns', region_name='us-east-1'))
        topic_name = f'user-notify-{time.time_ns()}'
        topic = sns_wrapper.create_topic(topic_name)
        trip = TripDetails()
        document = trip.find_by_email(user_email)
        found = False
        if document:
            for taxis in document['taxi_list']:
                if taxis['plate'] == taxi_plate:
                    found = True
                    break
            if found:
                print(f"Subscribing {user_email} to {topic_name}.")
                email_sub = sns_wrapper.subscribe(topic, 'email', user_email)
                answer = input(
                        f"Confirmation email sent to {user_email}. To receive SNS messages, "
                        f"follow the instructions in the email. When confirmed, press "
                        f"Enter to continue.")
                while (email_sub.attributes['PendingConfirmation'] == 'true' and answer.lower() != 's'):
                    answer = input(
                            f"Email address {user_email} is not confirmed. Follow the "
                            f"instructions in the email to confirm and receive SNS messages. "
                            f"Press Enter when confirmed or enter 's' to skip. ")
                    email_sub.reload()
                    print(f"Publishing a message to {topic_name}")
                    sns_wrapper.publish_message(
                            topic, f'Notification!Taxi with email {taxi_plate} is waiting for this taxi')
                self.update_by_email(user_email, TRIP_STATE[2])

    def accept_and_start_trip(self, taxi_plate, user_email):
        taxi = TaxiModel()
        user = UserModel()
        document = taxi.find_by_plate(taxi_plate)
        if document:
            taxi.update_by_plate(taxi_plate)
        document1 = user.find_by_email(user_email)
        if document1:
            user.update_by_email(user_email)
        document2 = self.find_by_email(user_email)
        if document2:
            self.update_by_email(user_email, TRIP_STATE[3])

