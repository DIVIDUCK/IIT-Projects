# Imports Database class from the project to provide basic functionality for database access
from database import Database
# Imports ObjectId to convert to the correct format before querying in the db
from bson.objectid import ObjectId
# Imports datetime class to create timestamp for accessing and dumping data into the daily report collection
from datetime import datetime
# Imports reduce for calculating maximum, minimum and average for the daily report collection
import functools


class Model:
    # _db containing the object to the database class accessing the database
    def __init__(self):
        self._db = Database()

    # Function (starting with _) to be used as the base for all find functions
    def _find_in_db(self, key, coll_name):
        user_document = self._db.get_single_data(coll_name, key)
        return user_document

    # Function (starting with _) to be used as the base for finding all the data in a collection
    def _find_all(self, coll_name):
        document_cursor = self._db.get_all_data(coll_name)
        return document_cursor

    # Function (starting with _) to be used as the base for finding multiple data in a collection
    def _find_multiple(self, key, coll_name):
        document_cursor = self._db.get_multiple_data(coll_name, key)
        return document_cursor

    # Function that is overridden by the respective child classes for finding document by object_id
    def find_by_object_id(self, obj_id):
        pass

    # Function that is overridden by the respective child classes for inserting into the database collections
    def insert(self, *args):
        pass


# User document contains username (String), email (String), and role (String) fields
class UserModel(Model):
    COLLECTION_NAME = 'users'

    def __init__(self):
        super().__init__()
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Since username should be unique in users collection, this provides a way to fetch the user document based on
    # the username
    def find_by_user_name(self, username):
        key = {'username': username}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # This first checks if a user already exists with that username. If it does, it populates latest_error and
    # returns -1 If a user doesn't already exist, it'll insert a new document and return the same to the caller
    def insert(self, *args):
        list1 = ['username', 'email', 'role', 'readonly_access', 'rw_access']
        self.__latest_error = ''
        user_document = self.find_by_user_name(args[0])
        if user_document:
            self.__latest_error = f'Username {args[0]} already exists'
            return -1
        loop = 0
        user_data = {}
        for dev_values in args:
            user_data.update({list1[loop]: dev_values})
            loop += 1

        user_obj_id = self._db.insert_single_data(self.COLLECTION_NAME, user_data)
        return self.find_by_object_id(user_obj_id)


# Device document contains device_id (String), desc (String), type (String - temperature/humidity) and
# manufacturer (String) fields
class DeviceModel(Model):
    COLLECTION_NAME = 'devices'

    def __init__(self):
        super().__init__()
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Since device id should be unique in devices collection, this provides a way to fetch the device document based
    # on the device id
    def find_by_device_id(self, device_id):
        key = {'device_id': device_id}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # Finds all the device documents from the device collection
    def find_all_devices(self):
        return self._find_all(self.COLLECTION_NAME)

    # This first checks if a device already exists with that device id. If it does, it populates latest_error and
    # returns -1. If a device doesn't already exist, it'll insert a new document and return the same to the caller
    def insert(self, *args):
        print("Entered Device Insert")
        self.__latest_error = ''
        device_document = self.find_by_device_id(args[0])
        if device_document:
            self.__latest_error = f'Device id {args[0]} already exists'
            return -1

        device_data = {'device_id': args[0], 'desc': args[1], 'type': args[2], 'manufacturer': args[3]}
        device_obj_id = self._db.insert_single_data(self.COLLECTION_NAME, device_data)
        return self.find_by_object_id(device_obj_id)


# Weather data document contains device_id (String), value (Integer), and timestamp (Date) fields
class WeatherDataModel(Model):
    COLLECTION_NAME = 'weather_data'

    def __init__(self):
        super().__init__()
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Since device id and timestamp should be unique in weather_data collection, this provides a way to fetch the
    # data document based on the device id and timestamp
    def find_by_device_timestamp(self, device_id, timestamp):
        key = {'device_id': device_id, 'timestamp': timestamp}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # Finds a document based on the unique auto-generated MongoDB object id 
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # This first checks if a data item already exists at a particular timestamp for a device id. If it does,
    # it populates latest_error and returns -1. If it doesn't already exist, it'll insert a new document and return
    # the same to the caller
    def insert(self, *args):
        self.__latest_error = ''
        w_data_document = self.find_by_device_timestamp(args[0], args[2])
        if w_data_document:
            self.__latest_error = f'Data for device id {args[0]} for timestamp {args[2]} already exists'
            return -1

        weather_data = {'device_id': args[0], 'value': args[1], 'timestamp': args[2]}
        w_data_obj_id = self._db.insert_single_data(self.COLLECTION_NAME, weather_data)
        return self.find_by_object_id(w_data_obj_id)

    # This is used to query multiple device documents from the devices collection
    # from a start timestamp to the end timestamp
    def query_multiple_data(self, device_id, start_timestamp, end_timestamp):
        self.__latest_error = ''
        key = {'device_id': device_id, 'timestamp': {'$gte': start_timestamp, '$lte': end_timestamp}}
        doc_cursor = self._find_multiple(key, self.COLLECTION_NAME)
        return doc_cursor


# Daily Report data document contains device_id (String), maximum (Integer), minimum (Integer),
# average (Float) and timestamp (Date) fields
class DailyReportModel(Model):
    COLLECTION_NAME = 'daily_report'

    def __init__(self):
        super().__init__()
        self.__Weather_Data = WeatherDataModel()
        self.__devices = DeviceModel()
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Since device id and timestamp should be unique in daily_report collection, this provides a way to fetch the
    # data document based on the device id and timestamp
    def find_by_device_timestamp(self, device_id, timestamp):
        key = {'device_id': device_id, 'timestamp': timestamp}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # Finds a document based on the unique auto-generated MongoDB object id
    def find_by_object_id(self, obj_id):
        key = {'_id': ObjectId(obj_id)}
        return self._find_in_db(key, self.COLLECTION_NAME)

    # This first checks if a data item already exists at a particular timestamp for a device id. If it does,
    # it populates latest_error and returns -1. If it doesn't already exist, it'll insert a new document and return
    # the same to the caller
    def insert(self, *args):
        self.__latest_error = ''
        daily_report_document = self.find_by_device_timestamp(args[0], args[4])
        if daily_report_document:
            self.__latest_error = f'Data for device id {args[0]} already exists'
            return -1
        daily_report = {'device_id': args[0], 'maximum': args[1], 'minimum': args[2],
                        'average': args[3], 'timestamp': args[4]}
        daily_report_obj_id = self._db.insert_single_data(self.COLLECTION_NAME, daily_report)
        return self.find_by_object_id(daily_report_obj_id)

    # This function finds the maximum, minimum and average value for each device per day and dumps it into the
    # daily_report collection
    def data_aggregator(self):
        self.__latest_error = ''
        value_list = []
        failurecount = 0
        successcount = 0
        failed_list = []
        device_cursor = self.__devices.find_all_devices()
        for devices in device_cursor:
            for day in range(1, 6):
                per_day_data = self.__Weather_Data.query_multiple_data(devices['device_id'],
                                                                       datetime(2020, 12, day, 0, 30, 0),
                                                                       datetime(2020, 12, day, 23, 30, 0))
                for x in per_day_data:
                    value_list.append(x['value'])
                maximum = functools.reduce(lambda a, b: a if a > b else b, value_list)
                minimum = functools.reduce(lambda a, b: a if a < b else b, value_list)
                sum1 = functools.reduce(lambda a, b: (a+b), value_list)
                average = sum1/len(value_list)
                report = self.insert(devices['device_id'], maximum, minimum, average, datetime(2020, 12, day))
                if report == -1:
                    failurecount += 1
                    failed_list.append(devices['device_id'] + str(datetime(2020, 12, day)))
                else:
                    successcount += 1
                value_list = []
        if successcount == 0:
            self.__latest_error = f'None of the data was inserted into the daily_report collection'
            return -1
        elif successcount > 0 and failurecount > 0:
            self.__latest_error = f'Only {successcount} documents were inserted into the daily_report collection'
            return 0
        else:
            self.__latest_error = f'All the documents were inserted into the daily_report collection : count {successcount}'
            return 0

    # This function queries the maximum, minimum and average value for a device for a date range
    def data_retrieval(self, device_id, start_timestamp, end_timestamp):
        self.__latest_error = ''
        key = {'device_id': device_id, 'timestamp': {'$gte': start_timestamp, '$lte': end_timestamp}}
        doc_cursor = self._find_multiple(key, self.COLLECTION_NAME)
        for documents in doc_cursor:
            device_id = documents['device_id']
            timestamp = documents['timestamp']
            maximum = documents['maximum']
            minimum = documents['minimum']
            average = documents['average']
            print(f'Device_Id : {device_id}, TimeStamp : {timestamp}, Maximum : {maximum},'
                  f' Minimum : {minimum}, Average : {average}')
        return 0