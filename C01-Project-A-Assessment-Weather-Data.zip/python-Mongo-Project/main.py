from model import UserModel, DeviceModel, WeatherDataModel, DailyReportModel
from Access import UserAccess, DeviceAccess, WeatherDataAccess, DailyReportAccess
from datetime import datetime

print("Test Cases:")
print("Test Case 1: Query the user document based on the user name for an admin user from the users collection")
print("Expected output: User Document for the user requested if present")
user_coll = UserModel()
user_access = UserAccess(user_coll, 'admin')
user_document = user_access.find_by_user_name('admin')
if user_document == -1:
    print(user_access.latest_error)
else:
    print(f'User Document: {user_document}')

print("Test Case 2: Query the user document based on the user name for a default user from the users collection")
print("Expected output: Error indicating access is denied")
user_coll = UserModel()
user_access = UserAccess(user_coll, 'user_1')
user_document = user_access.find_by_user_name('admin')
if user_document == -1:
    print(user_access.latest_error)
else:
    print(f'User Document: {user_document}')

print("Test Case 3: Query the user document based on the object Id for a default user from the users collection")
print("Expected output: Error indicating access is denied")
user_coll = UserModel()
user_access = UserAccess(user_coll, 'user_2')
user_document = user_access.find_by_object_id('60eb3471339100c57a73b206')
if user_document == -1:
    print(user_access.latest_error)
else:
    print(user_document)

print("Test Case 4: Insert a user document into the users collection as an admin user")
print("Expected output: User Document is inserted if not inserted already")
user_coll = UserModel()
user_access = UserAccess(user_coll, 'admin')
user_document = user_access.insert('test_4', 'test_4@example.com', 'default', ['DH070', 'DH100', 'DT078'], ['DT001'])
if user_document == -1:
    print(user_access.latest_error)
else:
    print(user_document)

print("Test Case 5: Insert a user document into the users collection as a default user")
print("Expected output: Error indicating access is denied")
user_coll = UserModel()
user_access = UserAccess(user_coll, 'test_4')
user_document = user_access.insert('test_5', 'test_5@example.com', 'default')
if user_document == -1:
    print(user_access.latest_error)
else:
    print(user_document)

print("Test Case 6: Query the device document based on the device name for an admin user from the devices collection")
print("Expected output: Device Document for the device requested if present")
device_coll = DeviceModel()
device_access = DeviceAccess(device_coll, 'admin')
device_document = device_access.find_by_device_id('DT002')
if device_document:
    print(device_document)
else:
    print(device_access.latest_error)

print("Test Case 7: Query the device document based on the device name for a default user from the devices collection."
      "The device is added as part of readonly access")
print("Expected output: Device Document for the device requested if present")
device_coll = DeviceModel()
device_access = DeviceAccess(device_coll, 'user_1')
device_document = device_access.find_by_device_id('DT002')
if device_document:
    print(device_document)
else:
    print(device_access.latest_error)

print("Test Case 8: Insert into the devices collection for a default user."
      " The device is added as part of readonly devices")
print("Expected output: Message displaying access is rejected")
device_coll = DeviceModel()
device_access = DeviceAccess(device_coll, 'user_1')
device_document = device_access.insert('DT001', 'Temperature Sensor', 'Temperature', 'Acme')
if device_document == -1:
    print(device_access.latest_error)
else:
    print(device_document)

print("Test Case 9: Query from the weather data collection for a default user."
      " The device is added as part of readwrite devices")
print("Expected output: Message displaying access is rejected")
w_data_coll = WeatherDataModel()
w_data_access = WeatherDataAccess(w_data_coll, 'user_2')
w_data_document = w_data_access.find_by_device_timestamp('DT002', datetime(2020, 12, 2, 13, 30, 0))
if w_data_document == -1:
    print(w_data_access.latest_error)
else:
    print(w_data_document)

print("Test Case 10: Insert into the weather data collection for a default user."
      " The device is added as part of readwrite devices")
print("Expected output: Device Document for the device requested if present")
w_data_coll = WeatherDataModel()
w_data_access = WeatherDataAccess(w_data_coll, 'user_1')
w_data_document = w_data_access.insert('DH002', 12, datetime(2020, 12, 2, 13, 30, 0))
if w_data_document == -1:
    print(w_data_access.latest_error)
else:
    print(w_data_document)

print("Test Case 11: Run the data aggregator to dump data into the daily report collection")
print("Expected output: Data should be added to the daily report collection if not already added. "
      "Partial update also possible and will be indicated")
daily_report_coll = DailyReportModel()
daily_report_access = DailyReportAccess(daily_report_coll, 'admin')
daily_document = daily_report_access.data_aggregator()
if daily_document == -1:
    print(daily_report_access.latest_error)
else:
    print(daily_document)

print("Test Case 12: Run the query on daily report to get the maximum, minimum and average values for a range of days")
print("Expected output: All the documents retrieved will be printed")
daily_report_coll = DailyReportModel()
daily_report_access = DailyReportAccess(daily_report_coll, 'admin')
value = daily_report_access.data_retrieval('DT004', datetime(2020, 12, 2), datetime(2020, 12, 5))
if value == -1:
    print(daily_report_access.latest_error)