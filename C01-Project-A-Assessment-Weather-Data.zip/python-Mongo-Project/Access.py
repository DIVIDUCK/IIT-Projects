# Imports all the model class from the project to provide basic functionality for user access control
from model import Model, UserModel


# This is the set of access control classes for providing authorization to different users and acts as a wrapper
# around the original model classes

class Access(Model):

    def __init__(self, model, access_username):
        super().__init__()
        self._service_model = model
        self._access_username = access_username
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Common function for accessing the role of the given username
    def _get_role(self):
        key = {'username': self._access_username}
        return self._find_in_db(key, UserModel.COLLECTION_NAME)

    def _check_access(self, primary_key, access):
        pass

    def insert(self, *args):
        pass

    def find_by_object_id(self, obj_id):
        pass


class UserAccess(Access):

    def __init__(self, model, access_username):
        super().__init__(model, access_username)
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    def _check_access(self, primary_key, access):
        user_document = self._get_role()
        if user_document['role'] == 'admin':
            return True
        else:
            return False

    # Wrapper function for accessing the user document of the given username with access control
    def find_by_user_name(self, user_name):
        self.__latest_error = ''
        if self._check_access(None, None):
            query_document = self._service_model.find_by_user_name(user_name)
            if query_document == -1:
                return self._service_model.latest_error
            else:
                return query_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

    # Wrapper function for accessing the user document of the given object Id with access control
    def find_by_object_id(self, obj_id):
        self.__latest_error = ''
        if self._check_access(None, None):
            query_document = self._service_model.find_by_object_id(obj_id)
            if query_document == -1:
                return self._service_model.latest_error
            else:
                return query_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

    # Wrapper function for inserting a user document with access control
    def insert(self, *args):
        self.__latest_error = ''
        if self._check_access(None, None):
            ins_document = self._service_model.insert(*args)
            if ins_document == -1:
                return self._service_model.latest_error
            else:
                return ins_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1


class DeviceAccess(Access):

    def __init__(self, model, access_username):
        super().__init__(model, access_username)
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    def _get_device(self, object_id):
        key = {'obj_id', object_id}
        return self._find_in_db(key, self._service_model.COLLECTION_NAME)

    # Function for checking the access permissions for the given device
    def _check_access(self, primary_key, access):
        user_document = self._get_role()
        if user_document['role'] == 'admin':
            return True
        else:
            if primary_key in user_document[access]:
                return True
            else:
                return False

    # Wrapper function for accessing the device document for the given device id with access control
    def find_by_device_id(self, device_id):
        self.__latest_error = ''
        if self._check_access(device_id, "readonly_access"):
            query_document = self._service_model.find_by_device_id(device_id)
            if query_document == -1:
                return self._service_model.latest_error
            else:
                return query_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

    # Wrapper function for accessing the device document for the given object id with access control
    def find_by_object_id(self, obj_id):
        self.__latest_error = ''
        if self._check_obj_access(obj_id):
            query_document = self._service_model.find_by_object_id(obj_id)
            if query_document == -1:
                return self._service_model.latest_error
            else:
                return query_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

    # Function for checking the access permissions for the given object Id for a device
    def _check_obj_access(self, object_id):
        user_document = self._get_role()
        if user_document['role'] == 'admin':
            return True
        else:
            device_document = self._get_device(object_id)
            device_id = device_document['device_id']
            if device_id in user_document['readonly_access']:
                return True
            else:
                return False

    # Wrapper function for inserting a device document with access control
    def insert(self, *args):
        self.__latest_error = ''
        if self._check_access(args[0], "rw_access"):
            ins_document = self._service_model.insert(*args)
            if ins_document == -1:
                return self._service_model.latest_error
            else:
                return ins_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1


class WeatherDataAccess(DeviceAccess):

    def __init__(self, model, access_username):
        super().__init__(model, access_username)
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Wrapper function for finding a weather report document with access control
    def find_by_device_timestamp(self, device_id, timestamp):
        self.__latest_error = ''
        if self._check_access(device_id, "readonly_access"):
            query_document = self._service_model.find_by_device_timestamp(device_id, timestamp)
            if query_document == -1:
                return self._service_model.latest_error
            else:
                return query_document
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1


class DailyReportAccess(WeatherDataAccess):

    def __init__(self, model, access_username):
        super().__init__(model, access_username)
        self.__latest_error = ''

    @property
    def latest_error(self):
        return self.__latest_error

    # Wrapper function for aggregating the weather report collection
    # into the daily report collection with access control
    def data_aggregator(self):
        self.__latest_error = ''
        if self._check_access(None, None):
            val = self._service_model.data_aggregator()
            if val == -1:
                return self._service_model.latest_error
            else:
                return f'All the documents have been successfully inserted into the daily report collection'
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

    # Wrapper function for retrieving the data from the daily report collection
    def data_retrieval(self, device_id, start_timestamp, end_timestamp):
        self.__latest_error = ''
        if self._check_access(device_id, "readonly_access"):
            return self._service_model.data_retrieval(device_id, start_timestamp, end_timestamp)
        else:
            self.__latest_error = f'The user {self._access_username} has no access'
            return -1

